//
//  ViewController.m
//  smashImageView
//
//  Created by 潘东 on 16/7/13.
//  Copyright © 2016年 Dream. All rights reserved.
//

#import "ViewController.h"
#import "smashEffect.h"
@interface ViewController ()
@property (weak, nonatomic) smashEffect *smashView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    
    
    smashEffect *smashView = [[smashEffect alloc]initWithFrame:CGRectMake(20, 20, width-40, 335*(height/667)) Image:[UIImage imageNamed:@"IMG_0668"]];
    
//    smashView.smashImage = [UIImage imageNamed:@"IMG_0668"];
    [self.view addSubview:smashView];
    self.smashView = smashView;
}
#pragma mark - 点击处理
//打乱
- (IBAction)smashClick:(id)sender {
    [self.smashView smash];
}
//还原
- (IBAction)restoreClick:(id)sender {
    [self.smashView restore];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
