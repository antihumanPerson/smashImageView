//
//  smashEffect.h
//  smashImageView
//
//  Created by 潘东 on 16/7/13.
//  Copyright © 2016年 Dream. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface smashEffect : UIView;
/**
 *  还原方法
 */
- (void)restore;
/**
 *  打碎方法
 */
- (void)smash;
/**
 *
 *  @param frame frame
 *  @param image 需要打碎的图片
 */
-(instancetype)initWithFrame:(CGRect)frame Image:(UIImage *)image;
@end
